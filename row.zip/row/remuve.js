(function() {
//    function removeElement(elementId)
//    {
//        element = document.getElementById(elementId);
//        if (element) {
//            element.parentNode.removeChild(element);
//        }
//    }
    var el = document.getElementById("example-grid-box");
    el.parentNode.removeChild(el);

})();